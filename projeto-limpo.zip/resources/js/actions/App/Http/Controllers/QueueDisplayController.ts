import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\QueueDisplayController::api
* @see app/Http/Controllers/QueueDisplayController.php:48
* @route '/api/display'
*/
export const api = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: api.url(options),
    method: 'get',
})

api.definition = {
    methods: ["get","head"],
    url: '/api/display',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\QueueDisplayController::api
* @see app/Http/Controllers/QueueDisplayController.php:48
* @route '/api/display'
*/
api.url = (options?: RouteQueryOptions) => {
    return api.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\QueueDisplayController::api
* @see app/Http/Controllers/QueueDisplayController.php:48
* @route '/api/display'
*/
api.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: api.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QueueDisplayController::api
* @see app/Http/Controllers/QueueDisplayController.php:48
* @route '/api/display'
*/
api.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: api.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\QueueDisplayController::api
* @see app/Http/Controllers/QueueDisplayController.php:48
* @route '/api/display'
*/
const apiForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: api.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QueueDisplayController::api
* @see app/Http/Controllers/QueueDisplayController.php:48
* @route '/api/display'
*/
apiForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: api.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QueueDisplayController::api
* @see app/Http/Controllers/QueueDisplayController.php:48
* @route '/api/display'
*/
apiForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: api.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

api.form = apiForm

/**
* @see \App\Http\Controllers\QueueDisplayController::index
* @see app/Http/Controllers/QueueDisplayController.php:16
* @route '/display'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/display',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\QueueDisplayController::index
* @see app/Http/Controllers/QueueDisplayController.php:16
* @route '/display'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\QueueDisplayController::index
* @see app/Http/Controllers/QueueDisplayController.php:16
* @route '/display'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QueueDisplayController::index
* @see app/Http/Controllers/QueueDisplayController.php:16
* @route '/display'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\QueueDisplayController::index
* @see app/Http/Controllers/QueueDisplayController.php:16
* @route '/display'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QueueDisplayController::index
* @see app/Http/Controllers/QueueDisplayController.php:16
* @route '/display'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QueueDisplayController::index
* @see app/Http/Controllers/QueueDisplayController.php:16
* @route '/display'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const QueueDisplayController = { api, index }

export default QueueDisplayController