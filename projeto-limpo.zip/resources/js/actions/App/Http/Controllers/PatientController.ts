import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PatientController::index
* @see app/Http/Controllers/PatientController.php:15
* @route '/api/patients'
*/
const index48e8c8d05bf8b19e01899b37d7b0bdb1 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index48e8c8d05bf8b19e01899b37d7b0bdb1.url(options),
    method: 'get',
})

index48e8c8d05bf8b19e01899b37d7b0bdb1.definition = {
    methods: ["get","head"],
    url: '/api/patients',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PatientController::index
* @see app/Http/Controllers/PatientController.php:15
* @route '/api/patients'
*/
index48e8c8d05bf8b19e01899b37d7b0bdb1.url = (options?: RouteQueryOptions) => {
    return index48e8c8d05bf8b19e01899b37d7b0bdb1.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PatientController::index
* @see app/Http/Controllers/PatientController.php:15
* @route '/api/patients'
*/
index48e8c8d05bf8b19e01899b37d7b0bdb1.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index48e8c8d05bf8b19e01899b37d7b0bdb1.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::index
* @see app/Http/Controllers/PatientController.php:15
* @route '/api/patients'
*/
index48e8c8d05bf8b19e01899b37d7b0bdb1.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index48e8c8d05bf8b19e01899b37d7b0bdb1.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PatientController::index
* @see app/Http/Controllers/PatientController.php:15
* @route '/api/patients'
*/
const index48e8c8d05bf8b19e01899b37d7b0bdb1Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index48e8c8d05bf8b19e01899b37d7b0bdb1.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::index
* @see app/Http/Controllers/PatientController.php:15
* @route '/api/patients'
*/
index48e8c8d05bf8b19e01899b37d7b0bdb1Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index48e8c8d05bf8b19e01899b37d7b0bdb1.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::index
* @see app/Http/Controllers/PatientController.php:15
* @route '/api/patients'
*/
index48e8c8d05bf8b19e01899b37d7b0bdb1Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index48e8c8d05bf8b19e01899b37d7b0bdb1.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index48e8c8d05bf8b19e01899b37d7b0bdb1.form = index48e8c8d05bf8b19e01899b37d7b0bdb1Form
/**
* @see \App\Http\Controllers\PatientController::index
* @see app/Http/Controllers/PatientController.php:15
* @route '/patients'
*/
const index000bd8667cb422c628aa39fd55791eee = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index000bd8667cb422c628aa39fd55791eee.url(options),
    method: 'get',
})

index000bd8667cb422c628aa39fd55791eee.definition = {
    methods: ["get","head"],
    url: '/patients',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PatientController::index
* @see app/Http/Controllers/PatientController.php:15
* @route '/patients'
*/
index000bd8667cb422c628aa39fd55791eee.url = (options?: RouteQueryOptions) => {
    return index000bd8667cb422c628aa39fd55791eee.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PatientController::index
* @see app/Http/Controllers/PatientController.php:15
* @route '/patients'
*/
index000bd8667cb422c628aa39fd55791eee.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index000bd8667cb422c628aa39fd55791eee.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::index
* @see app/Http/Controllers/PatientController.php:15
* @route '/patients'
*/
index000bd8667cb422c628aa39fd55791eee.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index000bd8667cb422c628aa39fd55791eee.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PatientController::index
* @see app/Http/Controllers/PatientController.php:15
* @route '/patients'
*/
const index000bd8667cb422c628aa39fd55791eeeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index000bd8667cb422c628aa39fd55791eee.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::index
* @see app/Http/Controllers/PatientController.php:15
* @route '/patients'
*/
index000bd8667cb422c628aa39fd55791eeeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index000bd8667cb422c628aa39fd55791eee.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::index
* @see app/Http/Controllers/PatientController.php:15
* @route '/patients'
*/
index000bd8667cb422c628aa39fd55791eeeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index000bd8667cb422c628aa39fd55791eee.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index000bd8667cb422c628aa39fd55791eee.form = index000bd8667cb422c628aa39fd55791eeeForm

export const index = {
    '/api/patients': index48e8c8d05bf8b19e01899b37d7b0bdb1,
    '/patients': index000bd8667cb422c628aa39fd55791eee,
}

/**
* @see \App\Http\Controllers\PatientController::store
* @see app/Http/Controllers/PatientController.php:41
* @route '/api/patients'
*/
const store48e8c8d05bf8b19e01899b37d7b0bdb1 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store48e8c8d05bf8b19e01899b37d7b0bdb1.url(options),
    method: 'post',
})

store48e8c8d05bf8b19e01899b37d7b0bdb1.definition = {
    methods: ["post"],
    url: '/api/patients',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PatientController::store
* @see app/Http/Controllers/PatientController.php:41
* @route '/api/patients'
*/
store48e8c8d05bf8b19e01899b37d7b0bdb1.url = (options?: RouteQueryOptions) => {
    return store48e8c8d05bf8b19e01899b37d7b0bdb1.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PatientController::store
* @see app/Http/Controllers/PatientController.php:41
* @route '/api/patients'
*/
store48e8c8d05bf8b19e01899b37d7b0bdb1.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store48e8c8d05bf8b19e01899b37d7b0bdb1.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PatientController::store
* @see app/Http/Controllers/PatientController.php:41
* @route '/api/patients'
*/
const store48e8c8d05bf8b19e01899b37d7b0bdb1Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store48e8c8d05bf8b19e01899b37d7b0bdb1.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PatientController::store
* @see app/Http/Controllers/PatientController.php:41
* @route '/api/patients'
*/
store48e8c8d05bf8b19e01899b37d7b0bdb1Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store48e8c8d05bf8b19e01899b37d7b0bdb1.url(options),
    method: 'post',
})

store48e8c8d05bf8b19e01899b37d7b0bdb1.form = store48e8c8d05bf8b19e01899b37d7b0bdb1Form
/**
* @see \App\Http\Controllers\PatientController::store
* @see app/Http/Controllers/PatientController.php:41
* @route '/patients'
*/
const store000bd8667cb422c628aa39fd55791eee = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store000bd8667cb422c628aa39fd55791eee.url(options),
    method: 'post',
})

store000bd8667cb422c628aa39fd55791eee.definition = {
    methods: ["post"],
    url: '/patients',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PatientController::store
* @see app/Http/Controllers/PatientController.php:41
* @route '/patients'
*/
store000bd8667cb422c628aa39fd55791eee.url = (options?: RouteQueryOptions) => {
    return store000bd8667cb422c628aa39fd55791eee.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PatientController::store
* @see app/Http/Controllers/PatientController.php:41
* @route '/patients'
*/
store000bd8667cb422c628aa39fd55791eee.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store000bd8667cb422c628aa39fd55791eee.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PatientController::store
* @see app/Http/Controllers/PatientController.php:41
* @route '/patients'
*/
const store000bd8667cb422c628aa39fd55791eeeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store000bd8667cb422c628aa39fd55791eee.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PatientController::store
* @see app/Http/Controllers/PatientController.php:41
* @route '/patients'
*/
store000bd8667cb422c628aa39fd55791eeeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store000bd8667cb422c628aa39fd55791eee.url(options),
    method: 'post',
})

store000bd8667cb422c628aa39fd55791eee.form = store000bd8667cb422c628aa39fd55791eeeForm

export const store = {
    '/api/patients': store48e8c8d05bf8b19e01899b37d7b0bdb1,
    '/patients': store000bd8667cb422c628aa39fd55791eee,
}

/**
* @see \App\Http\Controllers\PatientController::show
* @see app/Http/Controllers/PatientController.php:67
* @route '/api/patients/{id}'
*/
const show8fe36946b79ded19ebcda40fce7c6f89 = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show8fe36946b79ded19ebcda40fce7c6f89.url(args, options),
    method: 'get',
})

show8fe36946b79ded19ebcda40fce7c6f89.definition = {
    methods: ["get","head"],
    url: '/api/patients/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PatientController::show
* @see app/Http/Controllers/PatientController.php:67
* @route '/api/patients/{id}'
*/
show8fe36946b79ded19ebcda40fce7c6f89.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return show8fe36946b79ded19ebcda40fce7c6f89.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PatientController::show
* @see app/Http/Controllers/PatientController.php:67
* @route '/api/patients/{id}'
*/
show8fe36946b79ded19ebcda40fce7c6f89.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show8fe36946b79ded19ebcda40fce7c6f89.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::show
* @see app/Http/Controllers/PatientController.php:67
* @route '/api/patients/{id}'
*/
show8fe36946b79ded19ebcda40fce7c6f89.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show8fe36946b79ded19ebcda40fce7c6f89.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PatientController::show
* @see app/Http/Controllers/PatientController.php:67
* @route '/api/patients/{id}'
*/
const show8fe36946b79ded19ebcda40fce7c6f89Form = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show8fe36946b79ded19ebcda40fce7c6f89.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::show
* @see app/Http/Controllers/PatientController.php:67
* @route '/api/patients/{id}'
*/
show8fe36946b79ded19ebcda40fce7c6f89Form.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show8fe36946b79ded19ebcda40fce7c6f89.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::show
* @see app/Http/Controllers/PatientController.php:67
* @route '/api/patients/{id}'
*/
show8fe36946b79ded19ebcda40fce7c6f89Form.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show8fe36946b79ded19ebcda40fce7c6f89.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show8fe36946b79ded19ebcda40fce7c6f89.form = show8fe36946b79ded19ebcda40fce7c6f89Form
/**
* @see \App\Http\Controllers\PatientController::show
* @see app/Http/Controllers/PatientController.php:67
* @route '/patients/{patient}'
*/
const show3aaf97f6f468be8afe55ea1e3579ebd3 = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show3aaf97f6f468be8afe55ea1e3579ebd3.url(args, options),
    method: 'get',
})

show3aaf97f6f468be8afe55ea1e3579ebd3.definition = {
    methods: ["get","head"],
    url: '/patients/{patient}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PatientController::show
* @see app/Http/Controllers/PatientController.php:67
* @route '/patients/{patient}'
*/
show3aaf97f6f468be8afe55ea1e3579ebd3.url = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { patient: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { patient: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            patient: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        patient: typeof args.patient === 'object'
        ? args.patient.id
        : args.patient,
    }

    return show3aaf97f6f468be8afe55ea1e3579ebd3.definition.url
            .replace('{patient}', parsedArgs.patient.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PatientController::show
* @see app/Http/Controllers/PatientController.php:67
* @route '/patients/{patient}'
*/
show3aaf97f6f468be8afe55ea1e3579ebd3.get = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show3aaf97f6f468be8afe55ea1e3579ebd3.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::show
* @see app/Http/Controllers/PatientController.php:67
* @route '/patients/{patient}'
*/
show3aaf97f6f468be8afe55ea1e3579ebd3.head = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show3aaf97f6f468be8afe55ea1e3579ebd3.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PatientController::show
* @see app/Http/Controllers/PatientController.php:67
* @route '/patients/{patient}'
*/
const show3aaf97f6f468be8afe55ea1e3579ebd3Form = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show3aaf97f6f468be8afe55ea1e3579ebd3.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::show
* @see app/Http/Controllers/PatientController.php:67
* @route '/patients/{patient}'
*/
show3aaf97f6f468be8afe55ea1e3579ebd3Form.get = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show3aaf97f6f468be8afe55ea1e3579ebd3.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::show
* @see app/Http/Controllers/PatientController.php:67
* @route '/patients/{patient}'
*/
show3aaf97f6f468be8afe55ea1e3579ebd3Form.head = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show3aaf97f6f468be8afe55ea1e3579ebd3.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show3aaf97f6f468be8afe55ea1e3579ebd3.form = show3aaf97f6f468be8afe55ea1e3579ebd3Form

export const show = {
    '/api/patients/{id}': show8fe36946b79ded19ebcda40fce7c6f89,
    '/patients/{patient}': show3aaf97f6f468be8afe55ea1e3579ebd3,
}

/**
* @see \App\Http\Controllers\PatientController::update
* @see app/Http/Controllers/PatientController.php:93
* @route '/api/patients/{id}'
*/
const update8fe36946b79ded19ebcda40fce7c6f89 = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update8fe36946b79ded19ebcda40fce7c6f89.url(args, options),
    method: 'put',
})

update8fe36946b79ded19ebcda40fce7c6f89.definition = {
    methods: ["put"],
    url: '/api/patients/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\PatientController::update
* @see app/Http/Controllers/PatientController.php:93
* @route '/api/patients/{id}'
*/
update8fe36946b79ded19ebcda40fce7c6f89.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return update8fe36946b79ded19ebcda40fce7c6f89.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PatientController::update
* @see app/Http/Controllers/PatientController.php:93
* @route '/api/patients/{id}'
*/
update8fe36946b79ded19ebcda40fce7c6f89.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update8fe36946b79ded19ebcda40fce7c6f89.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\PatientController::update
* @see app/Http/Controllers/PatientController.php:93
* @route '/api/patients/{id}'
*/
const update8fe36946b79ded19ebcda40fce7c6f89Form = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update8fe36946b79ded19ebcda40fce7c6f89.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PatientController::update
* @see app/Http/Controllers/PatientController.php:93
* @route '/api/patients/{id}'
*/
update8fe36946b79ded19ebcda40fce7c6f89Form.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update8fe36946b79ded19ebcda40fce7c6f89.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update8fe36946b79ded19ebcda40fce7c6f89.form = update8fe36946b79ded19ebcda40fce7c6f89Form
/**
* @see \App\Http\Controllers\PatientController::update
* @see app/Http/Controllers/PatientController.php:93
* @route '/patients/{patient}'
*/
const update3aaf97f6f468be8afe55ea1e3579ebd3 = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update3aaf97f6f468be8afe55ea1e3579ebd3.url(args, options),
    method: 'put',
})

update3aaf97f6f468be8afe55ea1e3579ebd3.definition = {
    methods: ["put"],
    url: '/patients/{patient}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\PatientController::update
* @see app/Http/Controllers/PatientController.php:93
* @route '/patients/{patient}'
*/
update3aaf97f6f468be8afe55ea1e3579ebd3.url = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { patient: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { patient: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            patient: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        patient: typeof args.patient === 'object'
        ? args.patient.id
        : args.patient,
    }

    return update3aaf97f6f468be8afe55ea1e3579ebd3.definition.url
            .replace('{patient}', parsedArgs.patient.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PatientController::update
* @see app/Http/Controllers/PatientController.php:93
* @route '/patients/{patient}'
*/
update3aaf97f6f468be8afe55ea1e3579ebd3.put = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update3aaf97f6f468be8afe55ea1e3579ebd3.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\PatientController::update
* @see app/Http/Controllers/PatientController.php:93
* @route '/patients/{patient}'
*/
const update3aaf97f6f468be8afe55ea1e3579ebd3Form = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update3aaf97f6f468be8afe55ea1e3579ebd3.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PatientController::update
* @see app/Http/Controllers/PatientController.php:93
* @route '/patients/{patient}'
*/
update3aaf97f6f468be8afe55ea1e3579ebd3Form.put = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update3aaf97f6f468be8afe55ea1e3579ebd3.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update3aaf97f6f468be8afe55ea1e3579ebd3.form = update3aaf97f6f468be8afe55ea1e3579ebd3Form

export const update = {
    '/api/patients/{id}': update8fe36946b79ded19ebcda40fce7c6f89,
    '/patients/{patient}': update3aaf97f6f468be8afe55ea1e3579ebd3,
}

/**
* @see \App\Http\Controllers\PatientController::destroy
* @see app/Http/Controllers/PatientController.php:117
* @route '/api/patients/{id}'
*/
const destroy8fe36946b79ded19ebcda40fce7c6f89 = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy8fe36946b79ded19ebcda40fce7c6f89.url(args, options),
    method: 'delete',
})

destroy8fe36946b79ded19ebcda40fce7c6f89.definition = {
    methods: ["delete"],
    url: '/api/patients/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PatientController::destroy
* @see app/Http/Controllers/PatientController.php:117
* @route '/api/patients/{id}'
*/
destroy8fe36946b79ded19ebcda40fce7c6f89.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroy8fe36946b79ded19ebcda40fce7c6f89.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PatientController::destroy
* @see app/Http/Controllers/PatientController.php:117
* @route '/api/patients/{id}'
*/
destroy8fe36946b79ded19ebcda40fce7c6f89.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy8fe36946b79ded19ebcda40fce7c6f89.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\PatientController::destroy
* @see app/Http/Controllers/PatientController.php:117
* @route '/api/patients/{id}'
*/
const destroy8fe36946b79ded19ebcda40fce7c6f89Form = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy8fe36946b79ded19ebcda40fce7c6f89.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PatientController::destroy
* @see app/Http/Controllers/PatientController.php:117
* @route '/api/patients/{id}'
*/
destroy8fe36946b79ded19ebcda40fce7c6f89Form.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy8fe36946b79ded19ebcda40fce7c6f89.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy8fe36946b79ded19ebcda40fce7c6f89.form = destroy8fe36946b79ded19ebcda40fce7c6f89Form
/**
* @see \App\Http\Controllers\PatientController::destroy
* @see app/Http/Controllers/PatientController.php:117
* @route '/patients/{patient}'
*/
const destroy3aaf97f6f468be8afe55ea1e3579ebd3 = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy3aaf97f6f468be8afe55ea1e3579ebd3.url(args, options),
    method: 'delete',
})

destroy3aaf97f6f468be8afe55ea1e3579ebd3.definition = {
    methods: ["delete"],
    url: '/patients/{patient}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PatientController::destroy
* @see app/Http/Controllers/PatientController.php:117
* @route '/patients/{patient}'
*/
destroy3aaf97f6f468be8afe55ea1e3579ebd3.url = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { patient: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { patient: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            patient: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        patient: typeof args.patient === 'object'
        ? args.patient.id
        : args.patient,
    }

    return destroy3aaf97f6f468be8afe55ea1e3579ebd3.definition.url
            .replace('{patient}', parsedArgs.patient.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PatientController::destroy
* @see app/Http/Controllers/PatientController.php:117
* @route '/patients/{patient}'
*/
destroy3aaf97f6f468be8afe55ea1e3579ebd3.delete = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy3aaf97f6f468be8afe55ea1e3579ebd3.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\PatientController::destroy
* @see app/Http/Controllers/PatientController.php:117
* @route '/patients/{patient}'
*/
const destroy3aaf97f6f468be8afe55ea1e3579ebd3Form = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy3aaf97f6f468be8afe55ea1e3579ebd3.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PatientController::destroy
* @see app/Http/Controllers/PatientController.php:117
* @route '/patients/{patient}'
*/
destroy3aaf97f6f468be8afe55ea1e3579ebd3Form.delete = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy3aaf97f6f468be8afe55ea1e3579ebd3.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy3aaf97f6f468be8afe55ea1e3579ebd3.form = destroy3aaf97f6f468be8afe55ea1e3579ebd3Form

export const destroy = {
    '/api/patients/{id}': destroy8fe36946b79ded19ebcda40fce7c6f89,
    '/patients/{patient}': destroy3aaf97f6f468be8afe55ea1e3579ebd3,
}

/**
* @see \App\Http\Controllers\PatientController::create
* @see app/Http/Controllers/PatientController.php:33
* @route '/patients/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/patients/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PatientController::create
* @see app/Http/Controllers/PatientController.php:33
* @route '/patients/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PatientController::create
* @see app/Http/Controllers/PatientController.php:33
* @route '/patients/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::create
* @see app/Http/Controllers/PatientController.php:33
* @route '/patients/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PatientController::create
* @see app/Http/Controllers/PatientController.php:33
* @route '/patients/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::create
* @see app/Http/Controllers/PatientController.php:33
* @route '/patients/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::create
* @see app/Http/Controllers/PatientController.php:33
* @route '/patients/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\PatientController::edit
* @see app/Http/Controllers/PatientController.php:83
* @route '/patients/{patient}/edit'
*/
export const edit = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/patients/{patient}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PatientController::edit
* @see app/Http/Controllers/PatientController.php:83
* @route '/patients/{patient}/edit'
*/
edit.url = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { patient: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { patient: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            patient: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        patient: typeof args.patient === 'object'
        ? args.patient.id
        : args.patient,
    }

    return edit.definition.url
            .replace('{patient}', parsedArgs.patient.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PatientController::edit
* @see app/Http/Controllers/PatientController.php:83
* @route '/patients/{patient}/edit'
*/
edit.get = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::edit
* @see app/Http/Controllers/PatientController.php:83
* @route '/patients/{patient}/edit'
*/
edit.head = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PatientController::edit
* @see app/Http/Controllers/PatientController.php:83
* @route '/patients/{patient}/edit'
*/
const editForm = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::edit
* @see app/Http/Controllers/PatientController.php:83
* @route '/patients/{patient}/edit'
*/
editForm.get = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PatientController::edit
* @see app/Http/Controllers/PatientController.php:83
* @route '/patients/{patient}/edit'
*/
editForm.head = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

const PatientController = { index, store, show, update, destroy, create, edit }

export default PatientController