import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TriageController::index
* @see app/Http/Controllers/TriageController.php:18
* @route '/triage'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/triage',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TriageController::index
* @see app/Http/Controllers/TriageController.php:18
* @route '/triage'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TriageController::index
* @see app/Http/Controllers/TriageController.php:18
* @route '/triage'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TriageController::index
* @see app/Http/Controllers/TriageController.php:18
* @route '/triage'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\TriageController::index
* @see app/Http/Controllers/TriageController.php:18
* @route '/triage'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TriageController::index
* @see app/Http/Controllers/TriageController.php:18
* @route '/triage'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TriageController::index
* @see app/Http/Controllers/TriageController.php:18
* @route '/triage'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\TriageController::create
* @see app/Http/Controllers/TriageController.php:44
* @route '/triage/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/triage/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TriageController::create
* @see app/Http/Controllers/TriageController.php:44
* @route '/triage/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TriageController::create
* @see app/Http/Controllers/TriageController.php:44
* @route '/triage/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TriageController::create
* @see app/Http/Controllers/TriageController.php:44
* @route '/triage/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\TriageController::create
* @see app/Http/Controllers/TriageController.php:44
* @route '/triage/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TriageController::create
* @see app/Http/Controllers/TriageController.php:44
* @route '/triage/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TriageController::create
* @see app/Http/Controllers/TriageController.php:44
* @route '/triage/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\TriageController::store
* @see app/Http/Controllers/TriageController.php:58
* @route '/triage'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/triage',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TriageController::store
* @see app/Http/Controllers/TriageController.php:58
* @route '/triage'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TriageController::store
* @see app/Http/Controllers/TriageController.php:58
* @route '/triage'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\TriageController::store
* @see app/Http/Controllers/TriageController.php:58
* @route '/triage'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\TriageController::store
* @see app/Http/Controllers/TriageController.php:58
* @route '/triage'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\TriageController::show
* @see app/Http/Controllers/TriageController.php:100
* @route '/triage/{triage}'
*/
export const show = (args: { triage: number | { id: number } } | [triage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/triage/{triage}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TriageController::show
* @see app/Http/Controllers/TriageController.php:100
* @route '/triage/{triage}'
*/
show.url = (args: { triage: number | { id: number } } | [triage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { triage: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { triage: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            triage: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        triage: typeof args.triage === 'object'
        ? args.triage.id
        : args.triage,
    }

    return show.definition.url
            .replace('{triage}', parsedArgs.triage.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TriageController::show
* @see app/Http/Controllers/TriageController.php:100
* @route '/triage/{triage}'
*/
show.get = (args: { triage: number | { id: number } } | [triage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TriageController::show
* @see app/Http/Controllers/TriageController.php:100
* @route '/triage/{triage}'
*/
show.head = (args: { triage: number | { id: number } } | [triage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\TriageController::show
* @see app/Http/Controllers/TriageController.php:100
* @route '/triage/{triage}'
*/
const showForm = (args: { triage: number | { id: number } } | [triage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TriageController::show
* @see app/Http/Controllers/TriageController.php:100
* @route '/triage/{triage}'
*/
showForm.get = (args: { triage: number | { id: number } } | [triage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TriageController::show
* @see app/Http/Controllers/TriageController.php:100
* @route '/triage/{triage}'
*/
showForm.head = (args: { triage: number | { id: number } } | [triage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\TriageController::destroy
* @see app/Http/Controllers/TriageController.php:112
* @route '/triage/{triage}'
*/
export const destroy = (args: { triage: number | { id: number } } | [triage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/triage/{triage}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TriageController::destroy
* @see app/Http/Controllers/TriageController.php:112
* @route '/triage/{triage}'
*/
destroy.url = (args: { triage: number | { id: number } } | [triage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { triage: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { triage: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            triage: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        triage: typeof args.triage === 'object'
        ? args.triage.id
        : args.triage,
    }

    return destroy.definition.url
            .replace('{triage}', parsedArgs.triage.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TriageController::destroy
* @see app/Http/Controllers/TriageController.php:112
* @route '/triage/{triage}'
*/
destroy.delete = (args: { triage: number | { id: number } } | [triage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\TriageController::destroy
* @see app/Http/Controllers/TriageController.php:112
* @route '/triage/{triage}'
*/
const destroyForm = (args: { triage: number | { id: number } } | [triage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\TriageController::destroy
* @see app/Http/Controllers/TriageController.php:112
* @route '/triage/{triage}'
*/
destroyForm.delete = (args: { triage: number | { id: number } } | [triage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const TriageController = { index, create, store, show, destroy }

export default TriageController