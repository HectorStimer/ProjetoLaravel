import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\QueueController::index
* @see [unknown]:0
* @route '/api/queue'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/queue',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\QueueController::index
* @see [unknown]:0
* @route '/api/queue'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QueueController::index
* @see [unknown]:0
* @route '/api/queue'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\QueueController::index
* @see [unknown]:0
* @route '/api/queue'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\QueueController::index
* @see [unknown]:0
* @route '/api/queue'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\QueueController::index
* @see [unknown]:0
* @route '/api/queue'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\QueueController::index
* @see [unknown]:0
* @route '/api/queue'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\QueueController::enqueue
* @see [unknown]:0
* @route '/api/queue/enqueue'
*/
export const enqueue = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enqueue.url(options),
    method: 'post',
})

enqueue.definition = {
    methods: ["post"],
    url: '/api/queue/enqueue',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QueueController::enqueue
* @see [unknown]:0
* @route '/api/queue/enqueue'
*/
enqueue.url = (options?: RouteQueryOptions) => {
    return enqueue.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QueueController::enqueue
* @see [unknown]:0
* @route '/api/queue/enqueue'
*/
enqueue.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enqueue.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\QueueController::enqueue
* @see [unknown]:0
* @route '/api/queue/enqueue'
*/
const enqueueForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: enqueue.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\QueueController::enqueue
* @see [unknown]:0
* @route '/api/queue/enqueue'
*/
enqueueForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: enqueue.url(options),
    method: 'post',
})

enqueue.form = enqueueForm

/**
* @see \App\Http\Controllers\Api\QueueController::call
* @see [unknown]:0
* @route '/api/queue/{id}/call'
*/
export const call = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: call.url(args, options),
    method: 'post',
})

call.definition = {
    methods: ["post"],
    url: '/api/queue/{id}/call',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QueueController::call
* @see [unknown]:0
* @route '/api/queue/{id}/call'
*/
call.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return call.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QueueController::call
* @see [unknown]:0
* @route '/api/queue/{id}/call'
*/
call.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: call.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\QueueController::call
* @see [unknown]:0
* @route '/api/queue/{id}/call'
*/
const callForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: call.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\QueueController::call
* @see [unknown]:0
* @route '/api/queue/{id}/call'
*/
callForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: call.url(args, options),
    method: 'post',
})

call.form = callForm

/**
* @see \App\Http\Controllers\Api\QueueController::start
* @see [unknown]:0
* @route '/api/queue/{id}/start'
*/
export const start = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/api/queue/{id}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QueueController::start
* @see [unknown]:0
* @route '/api/queue/{id}/start'
*/
start.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return start.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QueueController::start
* @see [unknown]:0
* @route '/api/queue/{id}/start'
*/
start.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\QueueController::start
* @see [unknown]:0
* @route '/api/queue/{id}/start'
*/
const startForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: start.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\QueueController::start
* @see [unknown]:0
* @route '/api/queue/{id}/start'
*/
startForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: start.url(args, options),
    method: 'post',
})

start.form = startForm

/**
* @see \App\Http\Controllers\Api\QueueController::finish
* @see [unknown]:0
* @route '/api/queue/{id}/finish'
*/
export const finish = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finish.url(args, options),
    method: 'post',
})

finish.definition = {
    methods: ["post"],
    url: '/api/queue/{id}/finish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QueueController::finish
* @see [unknown]:0
* @route '/api/queue/{id}/finish'
*/
finish.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return finish.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QueueController::finish
* @see [unknown]:0
* @route '/api/queue/{id}/finish'
*/
finish.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finish.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\QueueController::finish
* @see [unknown]:0
* @route '/api/queue/{id}/finish'
*/
const finishForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: finish.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\QueueController::finish
* @see [unknown]:0
* @route '/api/queue/{id}/finish'
*/
finishForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: finish.url(args, options),
    method: 'post',
})

finish.form = finishForm

/**
* @see \App\Http\Controllers\Api\QueueController::cancel
* @see [unknown]:0
* @route '/api/queue/{id}/cancel'
*/
export const cancel = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/api/queue/{id}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QueueController::cancel
* @see [unknown]:0
* @route '/api/queue/{id}/cancel'
*/
cancel.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return cancel.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QueueController::cancel
* @see [unknown]:0
* @route '/api/queue/{id}/cancel'
*/
cancel.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\QueueController::cancel
* @see [unknown]:0
* @route '/api/queue/{id}/cancel'
*/
const cancelForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\QueueController::cancel
* @see [unknown]:0
* @route '/api/queue/{id}/cancel'
*/
cancelForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel.url(args, options),
    method: 'post',
})

cancel.form = cancelForm

/**
* @see \App\Http\Controllers\Api\QueueController::nextPatient
* @see [unknown]:0
* @route '/api/queue/next'
*/
export const nextPatient = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: nextPatient.url(options),
    method: 'get',
})

nextPatient.definition = {
    methods: ["get","head"],
    url: '/api/queue/next',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\QueueController::nextPatient
* @see [unknown]:0
* @route '/api/queue/next'
*/
nextPatient.url = (options?: RouteQueryOptions) => {
    return nextPatient.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QueueController::nextPatient
* @see [unknown]:0
* @route '/api/queue/next'
*/
nextPatient.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: nextPatient.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\QueueController::nextPatient
* @see [unknown]:0
* @route '/api/queue/next'
*/
nextPatient.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: nextPatient.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\QueueController::nextPatient
* @see [unknown]:0
* @route '/api/queue/next'
*/
const nextPatientForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: nextPatient.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\QueueController::nextPatient
* @see [unknown]:0
* @route '/api/queue/next'
*/
nextPatientForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: nextPatient.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\QueueController::nextPatient
* @see [unknown]:0
* @route '/api/queue/next'
*/
nextPatientForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: nextPatient.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

nextPatient.form = nextPatientForm

/**
* @see \App\Http\Controllers\Api\QueueController::getQueueForScreening
* @see [unknown]:0
* @route '/api/queue/screening'
*/
export const getQueueForScreening = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getQueueForScreening.url(options),
    method: 'get',
})

getQueueForScreening.definition = {
    methods: ["get","head"],
    url: '/api/queue/screening',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\QueueController::getQueueForScreening
* @see [unknown]:0
* @route '/api/queue/screening'
*/
getQueueForScreening.url = (options?: RouteQueryOptions) => {
    return getQueueForScreening.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QueueController::getQueueForScreening
* @see [unknown]:0
* @route '/api/queue/screening'
*/
getQueueForScreening.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getQueueForScreening.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\QueueController::getQueueForScreening
* @see [unknown]:0
* @route '/api/queue/screening'
*/
getQueueForScreening.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getQueueForScreening.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\QueueController::getQueueForScreening
* @see [unknown]:0
* @route '/api/queue/screening'
*/
const getQueueForScreeningForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getQueueForScreening.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\QueueController::getQueueForScreening
* @see [unknown]:0
* @route '/api/queue/screening'
*/
getQueueForScreeningForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getQueueForScreening.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\QueueController::getQueueForScreening
* @see [unknown]:0
* @route '/api/queue/screening'
*/
getQueueForScreeningForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getQueueForScreening.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getQueueForScreening.form = getQueueForScreeningForm

const QueueController = { index, enqueue, call, start, finish, cancel, nextPatient, getQueueForScreening }

export default QueueController