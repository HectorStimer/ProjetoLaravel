import DashboardController from './DashboardController'
import TriageController from './TriageController'
import QueueController from './QueueController'

const Api = {
    DashboardController: Object.assign(DashboardController, DashboardController),
    TriageController: Object.assign(TriageController, TriageController),
    QueueController: Object.assign(QueueController, QueueController),
}

export default Api