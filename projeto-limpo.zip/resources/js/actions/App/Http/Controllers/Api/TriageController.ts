import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\TriageController::store
* @see [unknown]:0
* @route '/api/triage'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/triage',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\TriageController::store
* @see [unknown]:0
* @route '/api/triage'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\TriageController::store
* @see [unknown]:0
* @route '/api/triage'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\TriageController::store
* @see [unknown]:0
* @route '/api/triage'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\TriageController::store
* @see [unknown]:0
* @route '/api/triage'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\TriageController::showByPatient
* @see [unknown]:0
* @route '/api/triage/{patient_id}'
*/
export const showByPatient = (args: { patient_id: string | number } | [patient_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showByPatient.url(args, options),
    method: 'get',
})

showByPatient.definition = {
    methods: ["get","head"],
    url: '/api/triage/{patient_id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\TriageController::showByPatient
* @see [unknown]:0
* @route '/api/triage/{patient_id}'
*/
showByPatient.url = (args: { patient_id: string | number } | [patient_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { patient_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            patient_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        patient_id: args.patient_id,
    }

    return showByPatient.definition.url
            .replace('{patient_id}', parsedArgs.patient_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\TriageController::showByPatient
* @see [unknown]:0
* @route '/api/triage/{patient_id}'
*/
showByPatient.get = (args: { patient_id: string | number } | [patient_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showByPatient.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\TriageController::showByPatient
* @see [unknown]:0
* @route '/api/triage/{patient_id}'
*/
showByPatient.head = (args: { patient_id: string | number } | [patient_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showByPatient.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\TriageController::showByPatient
* @see [unknown]:0
* @route '/api/triage/{patient_id}'
*/
const showByPatientForm = (args: { patient_id: string | number } | [patient_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showByPatient.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\TriageController::showByPatient
* @see [unknown]:0
* @route '/api/triage/{patient_id}'
*/
showByPatientForm.get = (args: { patient_id: string | number } | [patient_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showByPatient.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\TriageController::showByPatient
* @see [unknown]:0
* @route '/api/triage/{patient_id}'
*/
showByPatientForm.head = (args: { patient_id: string | number } | [patient_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showByPatient.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showByPatient.form = showByPatientForm

const TriageController = { store, showByPatient }

export default TriageController