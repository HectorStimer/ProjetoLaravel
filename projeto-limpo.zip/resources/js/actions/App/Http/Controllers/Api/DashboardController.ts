import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DashboardController::adminDashboard
* @see [unknown]:0
* @route '/api/dashboard/admin'
*/
export const adminDashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminDashboard.url(options),
    method: 'get',
})

adminDashboard.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/admin',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardController::adminDashboard
* @see [unknown]:0
* @route '/api/dashboard/admin'
*/
adminDashboard.url = (options?: RouteQueryOptions) => {
    return adminDashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardController::adminDashboard
* @see [unknown]:0
* @route '/api/dashboard/admin'
*/
adminDashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::adminDashboard
* @see [unknown]:0
* @route '/api/dashboard/admin'
*/
adminDashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminDashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::adminDashboard
* @see [unknown]:0
* @route '/api/dashboard/admin'
*/
const adminDashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: adminDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::adminDashboard
* @see [unknown]:0
* @route '/api/dashboard/admin'
*/
adminDashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: adminDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::adminDashboard
* @see [unknown]:0
* @route '/api/dashboard/admin'
*/
adminDashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: adminDashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

adminDashboard.form = adminDashboardForm

/**
* @see \App\Http\Controllers\Api\DashboardController::triagistDashboard
* @see [unknown]:0
* @route '/api/dashboard/triagist'
*/
export const triagistDashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: triagistDashboard.url(options),
    method: 'get',
})

triagistDashboard.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/triagist',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardController::triagistDashboard
* @see [unknown]:0
* @route '/api/dashboard/triagist'
*/
triagistDashboard.url = (options?: RouteQueryOptions) => {
    return triagistDashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardController::triagistDashboard
* @see [unknown]:0
* @route '/api/dashboard/triagist'
*/
triagistDashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: triagistDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::triagistDashboard
* @see [unknown]:0
* @route '/api/dashboard/triagist'
*/
triagistDashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: triagistDashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::triagistDashboard
* @see [unknown]:0
* @route '/api/dashboard/triagist'
*/
const triagistDashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: triagistDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::triagistDashboard
* @see [unknown]:0
* @route '/api/dashboard/triagist'
*/
triagistDashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: triagistDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::triagistDashboard
* @see [unknown]:0
* @route '/api/dashboard/triagist'
*/
triagistDashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: triagistDashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

triagistDashboard.form = triagistDashboardForm

/**
* @see \App\Http\Controllers\Api\DashboardController::doctorDashboard
* @see [unknown]:0
* @route '/api/dashboard/doctor'
*/
export const doctorDashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: doctorDashboard.url(options),
    method: 'get',
})

doctorDashboard.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/doctor',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardController::doctorDashboard
* @see [unknown]:0
* @route '/api/dashboard/doctor'
*/
doctorDashboard.url = (options?: RouteQueryOptions) => {
    return doctorDashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardController::doctorDashboard
* @see [unknown]:0
* @route '/api/dashboard/doctor'
*/
doctorDashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: doctorDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::doctorDashboard
* @see [unknown]:0
* @route '/api/dashboard/doctor'
*/
doctorDashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: doctorDashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::doctorDashboard
* @see [unknown]:0
* @route '/api/dashboard/doctor'
*/
const doctorDashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: doctorDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::doctorDashboard
* @see [unknown]:0
* @route '/api/dashboard/doctor'
*/
doctorDashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: doctorDashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::doctorDashboard
* @see [unknown]:0
* @route '/api/dashboard/doctor'
*/
doctorDashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: doctorDashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

doctorDashboard.form = doctorDashboardForm

const DashboardController = { adminDashboard, triagistDashboard, doctorDashboard }

export default DashboardController