import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardController::summary
* @see app/Http/Controllers/DashboardController.php:153
* @route '/api/dashboard/summary'
*/
export const summary = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summary.url(options),
    method: 'get',
})

summary.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::summary
* @see app/Http/Controllers/DashboardController.php:153
* @route '/api/dashboard/summary'
*/
summary.url = (options?: RouteQueryOptions) => {
    return summary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::summary
* @see app/Http/Controllers/DashboardController.php:153
* @route '/api/dashboard/summary'
*/
summary.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::summary
* @see app/Http/Controllers/DashboardController.php:153
* @route '/api/dashboard/summary'
*/
summary.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: summary.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DashboardController::summary
* @see app/Http/Controllers/DashboardController.php:153
* @route '/api/dashboard/summary'
*/
const summaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: summary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::summary
* @see app/Http/Controllers/DashboardController.php:153
* @route '/api/dashboard/summary'
*/
summaryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: summary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::summary
* @see app/Http/Controllers/DashboardController.php:153
* @route '/api/dashboard/summary'
*/
summaryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: summary.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

summary.form = summaryForm

/**
* @see \App\Http\Controllers\DashboardController::getQueueStatusStats
* @see app/Http/Controllers/DashboardController.php:173
* @route '/api/dashboard/stats/status'
*/
export const getQueueStatusStats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getQueueStatusStats.url(options),
    method: 'get',
})

getQueueStatusStats.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/stats/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::getQueueStatusStats
* @see app/Http/Controllers/DashboardController.php:173
* @route '/api/dashboard/stats/status'
*/
getQueueStatusStats.url = (options?: RouteQueryOptions) => {
    return getQueueStatusStats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::getQueueStatusStats
* @see app/Http/Controllers/DashboardController.php:173
* @route '/api/dashboard/stats/status'
*/
getQueueStatusStats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getQueueStatusStats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::getQueueStatusStats
* @see app/Http/Controllers/DashboardController.php:173
* @route '/api/dashboard/stats/status'
*/
getQueueStatusStats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getQueueStatusStats.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DashboardController::getQueueStatusStats
* @see app/Http/Controllers/DashboardController.php:173
* @route '/api/dashboard/stats/status'
*/
const getQueueStatusStatsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getQueueStatusStats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::getQueueStatusStats
* @see app/Http/Controllers/DashboardController.php:173
* @route '/api/dashboard/stats/status'
*/
getQueueStatusStatsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getQueueStatusStats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::getQueueStatusStats
* @see app/Http/Controllers/DashboardController.php:173
* @route '/api/dashboard/stats/status'
*/
getQueueStatusStatsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getQueueStatusStats.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getQueueStatusStats.form = getQueueStatusStatsForm

/**
* @see \App\Http\Controllers\DashboardController::getServiceStatistics
* @see app/Http/Controllers/DashboardController.php:192
* @route '/api/dashboard/stats/services'
*/
export const getServiceStatistics = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getServiceStatistics.url(options),
    method: 'get',
})

getServiceStatistics.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/stats/services',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::getServiceStatistics
* @see app/Http/Controllers/DashboardController.php:192
* @route '/api/dashboard/stats/services'
*/
getServiceStatistics.url = (options?: RouteQueryOptions) => {
    return getServiceStatistics.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::getServiceStatistics
* @see app/Http/Controllers/DashboardController.php:192
* @route '/api/dashboard/stats/services'
*/
getServiceStatistics.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getServiceStatistics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::getServiceStatistics
* @see app/Http/Controllers/DashboardController.php:192
* @route '/api/dashboard/stats/services'
*/
getServiceStatistics.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getServiceStatistics.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DashboardController::getServiceStatistics
* @see app/Http/Controllers/DashboardController.php:192
* @route '/api/dashboard/stats/services'
*/
const getServiceStatisticsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getServiceStatistics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::getServiceStatistics
* @see app/Http/Controllers/DashboardController.php:192
* @route '/api/dashboard/stats/services'
*/
getServiceStatisticsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getServiceStatistics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::getServiceStatistics
* @see app/Http/Controllers/DashboardController.php:192
* @route '/api/dashboard/stats/services'
*/
getServiceStatisticsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getServiceStatistics.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getServiceStatistics.form = getServiceStatisticsForm

/**
* @see \App\Http\Controllers\DashboardController::getDailyStats
* @see app/Http/Controllers/DashboardController.php:212
* @route '/api/dashboard/stats/daily'
*/
export const getDailyStats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDailyStats.url(options),
    method: 'get',
})

getDailyStats.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/stats/daily',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::getDailyStats
* @see app/Http/Controllers/DashboardController.php:212
* @route '/api/dashboard/stats/daily'
*/
getDailyStats.url = (options?: RouteQueryOptions) => {
    return getDailyStats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::getDailyStats
* @see app/Http/Controllers/DashboardController.php:212
* @route '/api/dashboard/stats/daily'
*/
getDailyStats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDailyStats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::getDailyStats
* @see app/Http/Controllers/DashboardController.php:212
* @route '/api/dashboard/stats/daily'
*/
getDailyStats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getDailyStats.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DashboardController::getDailyStats
* @see app/Http/Controllers/DashboardController.php:212
* @route '/api/dashboard/stats/daily'
*/
const getDailyStatsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDailyStats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::getDailyStats
* @see app/Http/Controllers/DashboardController.php:212
* @route '/api/dashboard/stats/daily'
*/
getDailyStatsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDailyStats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::getDailyStats
* @see app/Http/Controllers/DashboardController.php:212
* @route '/api/dashboard/stats/daily'
*/
getDailyStatsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDailyStats.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getDailyStats.form = getDailyStatsForm

/**
* @see \App\Http\Controllers\DashboardController::index
* @see app/Http/Controllers/DashboardController.php:18
* @route '/dashboard'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::index
* @see app/Http/Controllers/DashboardController.php:18
* @route '/dashboard'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::index
* @see app/Http/Controllers/DashboardController.php:18
* @route '/dashboard'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::index
* @see app/Http/Controllers/DashboardController.php:18
* @route '/dashboard'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DashboardController::index
* @see app/Http/Controllers/DashboardController.php:18
* @route '/dashboard'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::index
* @see app/Http/Controllers/DashboardController.php:18
* @route '/dashboard'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DashboardController::index
* @see app/Http/Controllers/DashboardController.php:18
* @route '/dashboard'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const DashboardController = { summary, getQueueStatusStats, getServiceStatistics, getDailyStats, index }

export default DashboardController