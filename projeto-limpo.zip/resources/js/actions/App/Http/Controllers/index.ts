import AuthController from './AuthController'
import QueueDisplayController from './QueueDisplayController'
import Api from './Api'
import PatientController from './PatientController'
import ServiceController from './ServiceController'
import DashboardController from './DashboardController'
import QueueController from './QueueController'
import TriageController from './TriageController'
import Settings from './Settings'

const Controllers = {
    AuthController: Object.assign(AuthController, AuthController),
    QueueDisplayController: Object.assign(QueueDisplayController, QueueDisplayController),
    Api: Object.assign(Api, Api),
    PatientController: Object.assign(PatientController, PatientController),
    ServiceController: Object.assign(ServiceController, ServiceController),
    DashboardController: Object.assign(DashboardController, DashboardController),
    QueueController: Object.assign(QueueController, QueueController),
    TriageController: Object.assign(TriageController, TriageController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers