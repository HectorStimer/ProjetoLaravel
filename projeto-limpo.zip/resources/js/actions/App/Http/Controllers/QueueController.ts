import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\QueueController::index
* @see app/Http/Controllers/QueueController.php:17
* @route '/queue'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/queue',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\QueueController::index
* @see app/Http/Controllers/QueueController.php:17
* @route '/queue'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\QueueController::index
* @see app/Http/Controllers/QueueController.php:17
* @route '/queue'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QueueController::index
* @see app/Http/Controllers/QueueController.php:17
* @route '/queue'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\QueueController::index
* @see app/Http/Controllers/QueueController.php:17
* @route '/queue'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QueueController::index
* @see app/Http/Controllers/QueueController.php:17
* @route '/queue'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QueueController::index
* @see app/Http/Controllers/QueueController.php:17
* @route '/queue'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\QueueController::store
* @see app/Http/Controllers/QueueController.php:44
* @route '/queue'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/queue',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\QueueController::store
* @see app/Http/Controllers/QueueController.php:44
* @route '/queue'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\QueueController::store
* @see app/Http/Controllers/QueueController.php:44
* @route '/queue'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QueueController::store
* @see app/Http/Controllers/QueueController.php:44
* @route '/queue'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QueueController::store
* @see app/Http/Controllers/QueueController.php:44
* @route '/queue'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\QueueController::callNext
* @see app/Http/Controllers/QueueController.php:88
* @route '/queue/call-next'
*/
export const callNext = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: callNext.url(options),
    method: 'post',
})

callNext.definition = {
    methods: ["post"],
    url: '/queue/call-next',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\QueueController::callNext
* @see app/Http/Controllers/QueueController.php:88
* @route '/queue/call-next'
*/
callNext.url = (options?: RouteQueryOptions) => {
    return callNext.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\QueueController::callNext
* @see app/Http/Controllers/QueueController.php:88
* @route '/queue/call-next'
*/
callNext.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: callNext.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QueueController::callNext
* @see app/Http/Controllers/QueueController.php:88
* @route '/queue/call-next'
*/
const callNextForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: callNext.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QueueController::callNext
* @see app/Http/Controllers/QueueController.php:88
* @route '/queue/call-next'
*/
callNextForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: callNext.url(options),
    method: 'post',
})

callNext.form = callNextForm

/**
* @see \App\Http\Controllers\QueueController::call
* @see app/Http/Controllers/QueueController.php:68
* @route '/queue/{id}/call'
*/
export const call = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: call.url(args, options),
    method: 'post',
})

call.definition = {
    methods: ["post"],
    url: '/queue/{id}/call',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\QueueController::call
* @see app/Http/Controllers/QueueController.php:68
* @route '/queue/{id}/call'
*/
call.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return call.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\QueueController::call
* @see app/Http/Controllers/QueueController.php:68
* @route '/queue/{id}/call'
*/
call.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: call.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QueueController::call
* @see app/Http/Controllers/QueueController.php:68
* @route '/queue/{id}/call'
*/
const callForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: call.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QueueController::call
* @see app/Http/Controllers/QueueController.php:68
* @route '/queue/{id}/call'
*/
callForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: call.url(args, options),
    method: 'post',
})

call.form = callForm

/**
* @see \App\Http\Controllers\QueueController::start
* @see app/Http/Controllers/QueueController.php:118
* @route '/queue/{id}/start'
*/
export const start = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/queue/{id}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\QueueController::start
* @see app/Http/Controllers/QueueController.php:118
* @route '/queue/{id}/start'
*/
start.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return start.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\QueueController::start
* @see app/Http/Controllers/QueueController.php:118
* @route '/queue/{id}/start'
*/
start.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QueueController::start
* @see app/Http/Controllers/QueueController.php:118
* @route '/queue/{id}/start'
*/
const startForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: start.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QueueController::start
* @see app/Http/Controllers/QueueController.php:118
* @route '/queue/{id}/start'
*/
startForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: start.url(args, options),
    method: 'post',
})

start.form = startForm

/**
* @see \App\Http\Controllers\QueueController::finish
* @see app/Http/Controllers/QueueController.php:138
* @route '/queue/{id}/finish'
*/
export const finish = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finish.url(args, options),
    method: 'post',
})

finish.definition = {
    methods: ["post"],
    url: '/queue/{id}/finish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\QueueController::finish
* @see app/Http/Controllers/QueueController.php:138
* @route '/queue/{id}/finish'
*/
finish.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return finish.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\QueueController::finish
* @see app/Http/Controllers/QueueController.php:138
* @route '/queue/{id}/finish'
*/
finish.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finish.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QueueController::finish
* @see app/Http/Controllers/QueueController.php:138
* @route '/queue/{id}/finish'
*/
const finishForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: finish.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QueueController::finish
* @see app/Http/Controllers/QueueController.php:138
* @route '/queue/{id}/finish'
*/
finishForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: finish.url(args, options),
    method: 'post',
})

finish.form = finishForm

/**
* @see \App\Http\Controllers\QueueController::cancel
* @see app/Http/Controllers/QueueController.php:158
* @route '/queue/{id}/cancel'
*/
export const cancel = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/queue/{id}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\QueueController::cancel
* @see app/Http/Controllers/QueueController.php:158
* @route '/queue/{id}/cancel'
*/
cancel.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return cancel.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\QueueController::cancel
* @see app/Http/Controllers/QueueController.php:158
* @route '/queue/{id}/cancel'
*/
cancel.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QueueController::cancel
* @see app/Http/Controllers/QueueController.php:158
* @route '/queue/{id}/cancel'
*/
const cancelForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QueueController::cancel
* @see app/Http/Controllers/QueueController.php:158
* @route '/queue/{id}/cancel'
*/
cancelForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel.url(args, options),
    method: 'post',
})

cancel.form = cancelForm

const QueueController = { index, store, callNext, call, start, finish, cancel }

export default QueueController