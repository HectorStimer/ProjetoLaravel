import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\QueueDisplayController::api
* @see app/Http/Controllers/QueueDisplayController.php:48
* @route '/api/display'
*/
export const api = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: api.url(options),
    method: 'get',
})

api.definition = {
    methods: ["get","head"],
    url: '/api/display',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\QueueDisplayController::api
* @see app/Http/Controllers/QueueDisplayController.php:48
* @route '/api/display'
*/
api.url = (options?: RouteQueryOptions) => {
    return api.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\QueueDisplayController::api
* @see app/Http/Controllers/QueueDisplayController.php:48
* @route '/api/display'
*/
api.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: api.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QueueDisplayController::api
* @see app/Http/Controllers/QueueDisplayController.php:48
* @route '/api/display'
*/
api.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: api.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\QueueDisplayController::api
* @see app/Http/Controllers/QueueDisplayController.php:48
* @route '/api/display'
*/
const apiForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: api.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QueueDisplayController::api
* @see app/Http/Controllers/QueueDisplayController.php:48
* @route '/api/display'
*/
apiForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: api.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QueueDisplayController::api
* @see app/Http/Controllers/QueueDisplayController.php:48
* @route '/api/display'
*/
apiForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: api.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

api.form = apiForm
